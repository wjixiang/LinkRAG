/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
/**
 * Recursively partial type that can be null.
 *
 * @deprecated Use types from the `partial_types` namespace instead, which provides type-safe partial implementations
 * @template T The type to make recursively partial.
 */
export type RecursivePartialNull<T> = T extends object ? {
    [P in keyof T]?: RecursivePartialNull<T[P]>;
} : T | null;
export interface Checked<T, CheckName extends string = string> {
    value: T;
    checks: Record<CheckName, Check>;
}
export interface Check {
    name: string;
    expr: string;
    status: "succeeded" | "failed";
}
export declare function all_succeeded<CheckName extends string>(checks: Record<CheckName, Check>): boolean;
export declare function get_checks<CheckName extends string>(checks: Record<CheckName, Check>): Check[];
export interface Entity {
    name: string;
    description: string;
    type: string;
}
export interface HyDE_rewrite_query {
    HyDE_answer: string;
}
export interface RetrievedDocument {
    content: string;
    metadata: string;
}
