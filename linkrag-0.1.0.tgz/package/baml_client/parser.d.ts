/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
import type { BamlRuntime, BamlCtxManager, ClientRegistry } from "@boundaryml/baml";
import type { partial_types } from "./partial_types";
import type { Entity, HyDE_rewrite_query } from "./types";
import type TypeBuilder from "./type_builder";
export declare class LlmResponseParser {
    private runtime;
    private ctxManager;
    constructor(runtime: BamlRuntime, ctxManager: BamlCtxManager);
    ExtractMainEntity(llmResponse: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
    }): Entity;
    GenerateAnswer(llmResponse: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
    }): string;
    HyDE_rewrite(llmResponse: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
    }): HyDE_rewrite_query;
}
export declare class LlmStreamParser {
    private runtime;
    private ctxManager;
    constructor(runtime: BamlRuntime, ctxManager: BamlCtxManager);
    ExtractMainEntity(llmResponse: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
    }): partial_types.Entity;
    GenerateAnswer(llmResponse: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
    }): string;
    HyDE_rewrite(llmResponse: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
    }): partial_types.HyDE_rewrite_query;
}
