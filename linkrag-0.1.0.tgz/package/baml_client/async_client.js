"use strict";
/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
Object.defineProperty(exports, "__esModule", { value: true });
exports.b = exports.BamlAsyncClient = void 0;
const baml_1 = require("@boundaryml/baml");
const async_request_1 = require("./async_request");
const parser_1 = require("./parser");
const globals_1 = require("./globals");
class BamlAsyncClient {
    constructor(runtime, ctxManager, bamlOptions) {
        this.runtime = runtime;
        this.ctxManager = ctxManager;
        this.streamClient = new BamlStreamClient(runtime, ctxManager, bamlOptions);
        this.httpRequest = new async_request_1.AsyncHttpRequest(runtime, ctxManager);
        this.httpStreamRequest = new async_request_1.AsyncHttpStreamRequest(runtime, ctxManager);
        this.llmResponseParser = new parser_1.LlmResponseParser(runtime, ctxManager);
        this.llmStreamParser = new parser_1.LlmStreamParser(runtime, ctxManager);
        this.bamlOptions = bamlOptions || {};
    }
    withOptions(bamlOptions) {
        return new BamlAsyncClient(this.runtime, this.ctxManager, bamlOptions);
    }
    get stream() {
        return this.streamClient;
    }
    get request() {
        return this.httpRequest;
    }
    get streamRequest() {
        return this.httpStreamRequest;
    }
    get parse() {
        return this.llmResponseParser;
    }
    get parseStream() {
        return this.llmStreamParser;
    }
    async ExtractMainEntity(chunk_text, __baml_options__) {
        try {
            const options = { ...this.bamlOptions, ...(__baml_options__ || {}) };
            const collector = options.collector ? (Array.isArray(options.collector) ? options.collector : [options.collector]) : [];
            const raw = await this.runtime.callFunction("ExtractMainEntity", {
                "chunk_text": chunk_text
            }, this.ctxManager.cloneContext(), options.tb?.__tb(), options.clientRegistry, collector);
            return raw.parsed(false);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    async GenerateAnswer(query, documents, language, __baml_options__) {
        try {
            const options = { ...this.bamlOptions, ...(__baml_options__ || {}) };
            const collector = options.collector ? (Array.isArray(options.collector) ? options.collector : [options.collector]) : [];
            const raw = await this.runtime.callFunction("GenerateAnswer", {
                "query": query, "documents": documents, "language": language
            }, this.ctxManager.cloneContext(), options.tb?.__tb(), options.clientRegistry, collector);
            return raw.parsed(false);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    async HyDE_rewrite(query, language, __baml_options__) {
        try {
            const options = { ...this.bamlOptions, ...(__baml_options__ || {}) };
            const collector = options.collector ? (Array.isArray(options.collector) ? options.collector : [options.collector]) : [];
            const raw = await this.runtime.callFunction("HyDE_rewrite", {
                "query": query, "language": language
            }, this.ctxManager.cloneContext(), options.tb?.__tb(), options.clientRegistry, collector);
            return raw.parsed(false);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
}
exports.BamlAsyncClient = BamlAsyncClient;
class BamlStreamClient {
    constructor(runtime, ctxManager, bamlOptions) {
        this.runtime = runtime;
        this.ctxManager = ctxManager;
        this.bamlOptions = bamlOptions || {};
    }
    ExtractMainEntity(chunk_text, __baml_options__) {
        try {
            const options = { ...this.bamlOptions, ...(__baml_options__ || {}) };
            const collector = options.collector ? (Array.isArray(options.collector) ? options.collector : [options.collector]) : [];
            const raw = this.runtime.streamFunction("ExtractMainEntity", {
                "chunk_text": chunk_text
            }, undefined, this.ctxManager.cloneContext(), options.tb?.__tb(), options.clientRegistry, collector);
            return new baml_1.BamlStream(raw, (a) => a, (a) => a, this.ctxManager.cloneContext());
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    GenerateAnswer(query, documents, language, __baml_options__) {
        try {
            const options = { ...this.bamlOptions, ...(__baml_options__ || {}) };
            const collector = options.collector ? (Array.isArray(options.collector) ? options.collector : [options.collector]) : [];
            const raw = this.runtime.streamFunction("GenerateAnswer", {
                "query": query, "documents": documents, "language": language
            }, undefined, this.ctxManager.cloneContext(), options.tb?.__tb(), options.clientRegistry, collector);
            return new baml_1.BamlStream(raw, (a) => a, (a) => a, this.ctxManager.cloneContext());
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    HyDE_rewrite(query, language, __baml_options__) {
        try {
            const options = { ...this.bamlOptions, ...(__baml_options__ || {}) };
            const collector = options.collector ? (Array.isArray(options.collector) ? options.collector : [options.collector]) : [];
            const raw = this.runtime.streamFunction("HyDE_rewrite", {
                "query": query, "language": language
            }, undefined, this.ctxManager.cloneContext(), options.tb?.__tb(), options.clientRegistry, collector);
            return new baml_1.BamlStream(raw, (a) => a, (a) => a, this.ctxManager.cloneContext());
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
}
exports.b = new BamlAsyncClient(globals_1.DO_NOT_USE_DIRECTLY_UNLESS_YOU_KNOW_WHAT_YOURE_DOING_RUNTIME, globals_1.DO_NOT_USE_DIRECTLY_UNLESS_YOU_KNOW_WHAT_YOURE_DOING_CTX);
