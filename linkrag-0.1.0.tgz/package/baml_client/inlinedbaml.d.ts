/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
export declare const getBamlFiles: () => {
    "HyDE.baml": string;
    "clients.baml": string;
    "entities_extraction.baml": string;
    "generators.baml": string;
    "rag_generation.baml": string;
};
