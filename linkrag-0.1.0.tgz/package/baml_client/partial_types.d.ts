/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
/******************************************************************************
*
*  These types are used for streaming, for when an instance of a type
*  is still being built up and any of its fields is not yet fully available.
*
******************************************************************************/
export interface StreamState<T> {
    value: T;
    state: "Pending" | "Incomplete" | "Complete";
}
export declare namespace partial_types {
    interface Entity {
        name?: (string | null);
        description?: (string | null);
        type?: (string | null);
    }
    interface HyDE_rewrite_query {
        HyDE_answer?: (string | null);
    }
    interface RetrievedDocument {
        content?: (string | null);
        metadata?: (string | null);
    }
}
