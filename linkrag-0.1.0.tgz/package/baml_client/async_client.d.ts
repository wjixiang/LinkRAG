/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
import type { BamlRuntime, BamlCtxManager, ClientRegistry, Collector } from "@boundaryml/baml";
import { BamlStream } from "@boundaryml/baml";
import type { RecursivePartialNull as MovedRecursivePartialNull } from "./types";
import type { partial_types } from "./partial_types";
import type { Entity, HyDE_rewrite_query, RetrievedDocument } from "./types";
import type TypeBuilder from "./type_builder";
import { AsyncHttpRequest, AsyncHttpStreamRequest } from "./async_request";
import { LlmResponseParser, LlmStreamParser } from "./parser";
/**
 * @deprecated Use RecursivePartialNull from 'baml_client/types' instead.
 */
export type RecursivePartialNull<T> = MovedRecursivePartialNull<T>;
type BamlCallOptions = {
    tb?: TypeBuilder;
    clientRegistry?: ClientRegistry;
    collector?: Collector | Collector[];
};
export declare class BamlAsyncClient {
    private runtime;
    private ctxManager;
    private streamClient;
    private httpRequest;
    private httpStreamRequest;
    private llmResponseParser;
    private llmStreamParser;
    private bamlOptions;
    constructor(runtime: BamlRuntime, ctxManager: BamlCtxManager, bamlOptions?: BamlCallOptions);
    withOptions(bamlOptions: BamlCallOptions): BamlAsyncClient;
    get stream(): BamlStreamClient;
    get request(): AsyncHttpRequest;
    get streamRequest(): AsyncHttpStreamRequest;
    get parse(): LlmResponseParser;
    get parseStream(): LlmStreamParser;
    ExtractMainEntity(chunk_text: string, __baml_options__?: BamlCallOptions): Promise<Entity>;
    GenerateAnswer(query: string, documents: RetrievedDocument[], language: string, __baml_options__?: BamlCallOptions): Promise<string>;
    HyDE_rewrite(query: string, language: string, __baml_options__?: BamlCallOptions): Promise<HyDE_rewrite_query>;
}
declare class BamlStreamClient {
    private runtime;
    private ctxManager;
    private bamlOptions;
    constructor(runtime: BamlRuntime, ctxManager: BamlCtxManager, bamlOptions?: BamlCallOptions);
    ExtractMainEntity(chunk_text: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
        collector?: Collector | Collector[];
    }): BamlStream<partial_types.Entity, Entity>;
    GenerateAnswer(query: string, documents: RetrievedDocument[], language: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
        collector?: Collector | Collector[];
    }): BamlStream<string, string>;
    HyDE_rewrite(query: string, language: string, __baml_options__?: {
        tb?: TypeBuilder;
        clientRegistry?: ClientRegistry;
        collector?: Collector | Collector[];
    }): BamlStream<partial_types.HyDE_rewrite_query, HyDE_rewrite_query>;
}
export declare const b: BamlAsyncClient;
export {};
