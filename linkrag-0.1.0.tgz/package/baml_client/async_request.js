"use strict";
/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
Object.defineProperty(exports, "__esModule", { value: true });
exports.AsyncHttpStreamRequest = exports.AsyncHttpRequest = void 0;
const baml_1 = require("@boundaryml/baml");
class AsyncHttpRequest {
    constructor(runtime, ctxManager) {
        this.runtime = runtime;
        this.ctxManager = ctxManager;
    }
    async ExtractMainEntity(chunk_text, __baml_options__) {
        try {
            return await this.runtime.buildRequest("ExtractMainEntity", {
                "chunk_text": chunk_text
            }, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry, false);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    async GenerateAnswer(query, documents, language, __baml_options__) {
        try {
            return await this.runtime.buildRequest("GenerateAnswer", {
                "query": query, "documents": documents, "language": language
            }, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry, false);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    async HyDE_rewrite(query, language, __baml_options__) {
        try {
            return await this.runtime.buildRequest("HyDE_rewrite", {
                "query": query, "language": language
            }, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry, false);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
}
exports.AsyncHttpRequest = AsyncHttpRequest;
class AsyncHttpStreamRequest {
    constructor(runtime, ctxManager) {
        this.runtime = runtime;
        this.ctxManager = ctxManager;
    }
    async ExtractMainEntity(chunk_text, __baml_options__) {
        try {
            return await this.runtime.buildRequest("ExtractMainEntity", {
                "chunk_text": chunk_text
            }, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry, true);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    async GenerateAnswer(query, documents, language, __baml_options__) {
        try {
            return await this.runtime.buildRequest("GenerateAnswer", {
                "query": query, "documents": documents, "language": language
            }, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry, true);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    async HyDE_rewrite(query, language, __baml_options__) {
        try {
            return await this.runtime.buildRequest("HyDE_rewrite", {
                "query": query, "language": language
            }, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry, true);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
}
exports.AsyncHttpStreamRequest = AsyncHttpStreamRequest;
