/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
import type { BamlRuntime, BamlCtxManager, ClientRegistry } from "@boundaryml/baml";
import { HTTPRequest } from "@boundaryml/baml";
import type { RetrievedDocument } from "./types";
import type TypeBuilder from "./type_builder";
type BamlCallOptions = {
    tb?: TypeBuilder;
    clientRegistry?: ClientRegistry;
};
export declare class AsyncHttpRequest {
    private runtime;
    private ctxManager;
    constructor(runtime: BamlRuntime, ctxManager: BamlCtxManager);
    ExtractMainEntity(chunk_text: string, __baml_options__?: BamlCallOptions): Promise<HTTPRequest>;
    GenerateAnswer(query: string, documents: RetrievedDocument[], language: string, __baml_options__?: BamlCallOptions): Promise<HTTPRequest>;
    HyDE_rewrite(query: string, language: string, __baml_options__?: BamlCallOptions): Promise<HTTPRequest>;
}
export declare class AsyncHttpStreamRequest {
    private runtime;
    private ctxManager;
    constructor(runtime: BamlRuntime, ctxManager: BamlCtxManager);
    ExtractMainEntity(chunk_text: string, __baml_options__?: BamlCallOptions): Promise<HTTPRequest>;
    GenerateAnswer(query: string, documents: RetrievedDocument[], language: string, __baml_options__?: BamlCallOptions): Promise<HTTPRequest>;
    HyDE_rewrite(query: string, language: string, __baml_options__?: BamlCallOptions): Promise<HTTPRequest>;
}
export {};
