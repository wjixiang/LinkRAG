/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
import { FieldType } from '@boundaryml/baml/native';
import { EnumBuilder, ClassBuilder, ClassViewer } from '@boundaryml/baml/type_builder';
export default class TypeBuilder {
    private tb;
    Entity: ClassViewer<'Entity', "name" | "description" | "type">;
    HyDE_rewrite_query: ClassViewer<'HyDE_rewrite_query', "HyDE_answer">;
    RetrievedDocument: ClassViewer<'RetrievedDocument', "content" | "metadata">;
    constructor();
    __tb(): import("@boundaryml/baml/native").TypeBuilder;
    string(): FieldType;
    literalString(value: string): FieldType;
    literalInt(value: number): FieldType;
    literalBool(value: boolean): FieldType;
    int(): FieldType;
    float(): FieldType;
    bool(): FieldType;
    list(type: FieldType): FieldType;
    null(): FieldType;
    map(key: FieldType, value: FieldType): FieldType;
    union(types: FieldType[]): FieldType;
    addClass<Name extends string>(name: Name): ClassBuilder<Name>;
    addEnum<Name extends string>(name: Name): EnumBuilder<Name>;
    addBaml(baml: string): void;
}
