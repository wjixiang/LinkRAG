"use strict";
/*************************************************************************************************

Welcome to Baml! To use this generated code, please run one of the following:

$ npm install @boundaryml/baml
$ yarn add @boundaryml/baml
$ pnpm add @boundaryml/baml

*************************************************************************************************/
Object.defineProperty(exports, "__esModule", { value: true });
exports.LlmStreamParser = exports.LlmResponseParser = void 0;
const baml_1 = require("@boundaryml/baml");
class LlmResponseParser {
    constructor(runtime, ctxManager) {
        this.runtime = runtime;
        this.ctxManager = ctxManager;
    }
    ExtractMainEntity(llmResponse, __baml_options__) {
        try {
            return this.runtime.parseLlmResponse("ExtractMainEntity", llmResponse, false, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    GenerateAnswer(llmResponse, __baml_options__) {
        try {
            return this.runtime.parseLlmResponse("GenerateAnswer", llmResponse, false, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    HyDE_rewrite(llmResponse, __baml_options__) {
        try {
            return this.runtime.parseLlmResponse("HyDE_rewrite", llmResponse, false, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
}
exports.LlmResponseParser = LlmResponseParser;
class LlmStreamParser {
    constructor(runtime, ctxManager) {
        this.runtime = runtime;
        this.ctxManager = ctxManager;
    }
    ExtractMainEntity(llmResponse, __baml_options__) {
        try {
            return this.runtime.parseLlmResponse("ExtractMainEntity", llmResponse, true, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    GenerateAnswer(llmResponse, __baml_options__) {
        try {
            return this.runtime.parseLlmResponse("GenerateAnswer", llmResponse, true, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
    HyDE_rewrite(llmResponse, __baml_options__) {
        try {
            return this.runtime.parseLlmResponse("HyDE_rewrite", llmResponse, true, this.ctxManager.cloneContext(), __baml_options__?.tb?.__tb(), __baml_options__?.clientRegistry);
        }
        catch (error) {
            throw (0, baml_1.toBamlError)(error);
        }
    }
}
exports.LlmStreamParser = LlmStreamParser;
